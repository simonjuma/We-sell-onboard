// db.js — selects the database engine based on DATABASE_URL, so the rest of
// the app (server.js, seed.js) can just `require('./db')` and call
// db.get/all/run/exec without knowing or caring which engine is active.
//
//   DATABASE_URL unset or a local path  -> lib/db-sqlite.js  (dev, zero deps)
//   DATABASE_URL starts with postgres:// -> lib/db-postgres.js (production, e.g. Supabase)
const isPostgres = /^postgres(ql)?:\/\//.test(process.env.DATABASE_URL || '');
module.exports = isPostgres ? require('./lib/db-postgres') : require('./lib/db-sqlite');
