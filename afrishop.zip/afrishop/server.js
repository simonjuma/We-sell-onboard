// server.js — Afrishop backend. Plain Node http server (no Express — this
// sandbox has no network access for npm install, so everything here runs on
// Node's standard library only; it is a drop-in candidate for Express later).
// Database engine (SQLite locally, Postgres/Supabase in production) is
// selected transparently by db.js based on DATABASE_URL.
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const crypto = require('crypto');

const db = require('./db');
const { hashPassword, verifyPassword, signSession, verifySession } = require('./lib/auth');
const {
  readJsonBody, sendJson, parseCookies, setCookie,
  isValidKenyanPhone, normalizeKenyanPhone, isValidEmail, slugify, orderNumber,
  parseImageDataUrl,
} = require('./lib/http');
const MpesaService = require('./lib/payments/mpesa');
const PayPalService = require('./lib/payments/paypal');
const { mpesaResultMessage } = require('./lib/payments/payment-errors');
const SupabaseStorageService = require('./lib/storage/supabase-storage');

const storage = new SupabaseStorageService({
  url: process.env.SUPABASE_URL,
  serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY,
  bucket: process.env.SUPABASE_STORAGE_BUCKET || 'product-images',
});

const mpesa = new MpesaService({
  consumerKey: process.env.MPESA_CONSUMER_KEY,
  consumerSecret: process.env.MPESA_CONSUMER_SECRET,
  shortcode: process.env.MPESA_SHORTCODE,
  passkey: process.env.MPESA_PASSKEY,
  environment: process.env.MPESA_ENV || 'sandbox',
  callbackUrl: process.env.MPESA_CALLBACK_URL,
});
const paypal = new PayPalService(process.env.PAYPAL_CLIENT_ID, process.env.PAYPAL_CLIENT_SECRET, process.env.PAYPAL_ENVIRONMENT || 'sandbox');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const UPLOADS_DIR = path.join(PUBLIC_DIR, 'uploads');
fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const isProd = process.env.NODE_ENV === 'production';
if (isProd && !process.env.CORS_ORIGIN) {
  console.warn('[server] CORS_ORIGIN not set in production — cross-origin requests will be blocked by default (same-origin requests from the app itself are unaffected). Set CORS_ORIGIN if the frontend is served from a different domain than the API.');
}

// ---------- auth helpers ----------
function getSession(req) {
  const cookies = parseCookies(req);
  return verifySession(cookies.afrishop_session);
}
function requireAuth(req, res, roles) {
  const session = getSession(req);
  if (!session) { sendJson(res, 401, { error: 'Not authenticated' }); return null; }
  if (roles && !roles.includes(session.role)) { sendJson(res, 403, { error: 'Not authorized for this action' }); return null; }
  return session;
}

// ---------- static file serving ----------
const MIME = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.xml': 'application/xml', '.txt': 'text/plain' };
function serveStatic(req, res, pathname) {
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);
  if (!filePath.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (!path.extname(filePath)) {
        fs.readFile(filePath + '.html', (err2, content2) => {
          if (err2) { res.writeHead(404); return res.end('Not found'); }
          res.writeHead(200, { 'Content-Type': 'text/html' });
          res.end(content2);
        });
        return;
      }
      res.writeHead(404); return res.end('Not found');
    }
    const ext = path.extname(filePath);
    const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream' };
    if (pathname.startsWith('/uploads/')) headers['Cache-Control'] = 'public, max-age=31536000, immutable';
    res.writeHead(200, headers);
    res.end(content);
  });
}

// ---------- rate limiting (per IP, sliding window) ----------
const rateLog = new Map();
function isRateLimited(req, limit, windowMs) {
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const arr = (rateLog.get(ip) || []).filter(t => now - t < windowMs);
  arr.push(now);
  rateLog.set(ip, arr);
  return arr.length > limit;
}
// Auth endpoints get a much tighter limit — brute-forcing a password should
// not be allowed the same budget as browsing the catalog.
const authRateLog = new Map();
function isAuthRateLimited(req, limit = 8, windowMs = 60_000) {
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const arr = (authRateLog.get(ip) || []).filter(t => now - t < windowMs);
  arr.push(now);
  authRateLog.set(ip, arr);
  return arr.length > limit;
}

// ============================================================
// Route handlers
// ============================================================
const routes = [];
function route(method, pattern, handler) {
  const keys = [];
  const regex = new RegExp('^' + pattern.replace(/:[^/]+/g, m => { keys.push(m.slice(1)); return '([^/]+)'; }) + '$');
  routes.push({ method, regex, keys, handler });
}

// ---- Auth ----
route('POST', '/api/auth/signup', async (req, res) => {
  const body = await readJsonBody(req);
  const { email, password, full_name, phone, role } = body;
  if (!isValidEmail(email)) return sendJson(res, 400, { error: 'A valid email is required' });
  if (!password || password.length < 8) return sendJson(res, 400, { error: 'Password must be at least 8 characters' });
  if (!full_name || !full_name.trim()) return sendJson(res, 400, { error: 'Full name is required' });
  if (phone && !isValidKenyanPhone(phone)) return sendJson(res, 400, { error: 'Enter a valid Kenyan phone number (e.g. 07XXXXXXXX)' });
  const finalRole = ['customer', 'seller'].includes(role) ? role : 'customer';

  const existing = await db.get('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
  if (existing) return sendJson(res, 409, { error: 'An account with this email already exists' });

  const { hash, salt } = hashPassword(password);
  const info = await db.run(
    `INSERT INTO users (email, password_hash, password_salt, full_name, phone, role) VALUES (?,?,?,?,?,?)`,
    [email.toLowerCase(), hash, salt, full_name.trim(), phone ? normalizeKenyanPhone(phone) : null, finalRole]
  );

  const token = signSession({ uid: info.lastInsertRowid, role: finalRole });
  setCookie(res, 'afrishop_session', token, { maxAge: 604800 });
  sendJson(res, 201, { id: info.lastInsertRowid, email: email.toLowerCase(), full_name, role: finalRole });
});

route('POST', '/api/auth/login', async (req, res) => {
  const { email, password } = await readJsonBody(req);
  const user = await db.get('SELECT * FROM users WHERE email = ?', [String(email || '').toLowerCase()]);
  if (!user || !verifyPassword(password || '', user.password_hash, user.password_salt)) {
    return sendJson(res, 401, { error: 'Incorrect email or password' });
  }
  if (user.status === 'suspended') return sendJson(res, 403, { error: 'This account has been suspended' });
  const token = signSession({ uid: user.id, role: user.role });
  setCookie(res, 'afrishop_session', token, { maxAge: 604800 });
  sendJson(res, 200, { id: user.id, email: user.email, full_name: user.full_name, role: user.role });
});

route('POST', '/api/auth/logout', async (req, res) => {
  setCookie(res, 'afrishop_session', '', { clear: true });
  sendJson(res, 200, { ok: true });
});

route('GET', '/api/auth/me', async (req, res) => {
  const session = getSession(req);
  if (!session) return sendJson(res, 200, { user: null });
  const user = await db.get('SELECT id, email, full_name, role, phone FROM users WHERE id = ?', [session.uid]);
  sendJson(res, 200, { user: user || null });
});

// ---- Categories ----
route('GET', '/api/categories', async (req, res) => {
  sendJson(res, 200, await db.all('SELECT * FROM categories ORDER BY name'));
});

// ---- Public product catalog ----
route('GET', '/api/products', async (req, res, query) => {
  let sql = `SELECT p.*, s.name AS store_name, s.slug AS store_slug,
             (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image,
             COALESCE(i.quantity, 0) AS stock
             FROM products p JOIN stores s ON s.id = p.store_id
             LEFT JOIN inventory i ON i.product_id = p.id
             WHERE p.is_active = 1 AND s.is_published = 1 AND s.status = 'active'`;
  const params = [];
  if (query.search) { sql += ' AND p.name LIKE ?'; params.push(`%${query.search}%`); }
  if (query.category) { sql += ' AND p.category_id = ?'; params.push(query.category); }
  if (query.store) { sql += ' AND s.slug = ?'; params.push(query.store); }
  if (query.min) { sql += ' AND COALESCE(p.sale_price_kes, p.price_kes) >= ?'; params.push(Number(query.min)); }
  if (query.max) { sql += ' AND COALESCE(p.sale_price_kes, p.price_kes) <= ?'; params.push(Number(query.max)); }
  sql += query.sort === 'price_asc' ? ' ORDER BY COALESCE(p.sale_price_kes,p.price_kes) ASC'
       : query.sort === 'price_desc' ? ' ORDER BY COALESCE(p.sale_price_kes,p.price_kes) DESC'
       : ' ORDER BY p.created_at DESC';
  sendJson(res, 200, await db.all(sql, params));
});

route('GET', '/api/products/:id', async (req, res, query, params) => {
  const product = await db.get(`SELECT p.*, s.name AS store_name, s.slug AS store_slug, COALESCE(i.quantity,0) AS stock
    FROM products p JOIN stores s ON s.id = p.store_id LEFT JOIN inventory i ON i.product_id = p.id
    WHERE p.id = ?`, [params.id]);
  if (!product) return sendJson(res, 404, { error: 'Product not found' });
  product.images = (await db.all('SELECT url FROM product_images WHERE product_id = ? ORDER BY sort_order', [params.id])).map(r => r.url);
  product.reviews = await db.all(`SELECT r.rating, r.comment, r.created_at, u.full_name FROM reviews r JOIN users u ON u.id = r.customer_id WHERE product_id = ? ORDER BY r.created_at DESC`, [params.id]);
  sendJson(res, 200, product);
});

route('GET', '/api/stores/:slug', async (req, res, query, params) => {
  const store = await db.get(`SELECT id, name, slug, description, logo_url, county, town FROM stores WHERE slug = ? AND status = 'active' AND is_published = 1`, [params.slug]);
  if (!store) return sendJson(res, 404, { error: 'Store not found' });
  sendJson(res, 200, store);
});

// ---- Cart (auth required, customer) ----
async function getOrCreateCart(userId) {
  let cart = await db.get('SELECT * FROM carts WHERE user_id = ?', [userId]);
  if (!cart) {
    const info = await db.run('INSERT INTO carts (user_id) VALUES (?)', [userId]);
    cart = { id: info.lastInsertRowid, user_id: userId };
  }
  return cart;
}
async function cartContents(cartId) {
  const items = await db.all(`SELECT ci.product_id, ci.quantity, p.name, p.price_kes, p.sale_price_kes,
    (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image
    FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.cart_id = ?`, [cartId]);
  const subtotal = items.reduce((sum, i) => sum + (i.sale_price_kes || i.price_kes) * i.quantity, 0);
  return { items, subtotal };
}

route('GET', '/api/cart', async (req, res) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const cart = await getOrCreateCart(session.uid);
  sendJson(res, 200, await cartContents(cart.id));
});

route('POST', '/api/cart/items', async (req, res) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const { product_id, quantity } = await readJsonBody(req);
  const product = await db.get('SELECT id FROM products WHERE id = ? AND is_active = 1', [product_id]);
  if (!product) return sendJson(res, 404, { error: 'Product not found' });
  const cart = await getOrCreateCart(session.uid);
  const existing = await db.get('SELECT * FROM cart_items WHERE cart_id = ? AND product_id = ?', [cart.id, product_id]);
  if (existing) {
    await db.run('UPDATE cart_items SET quantity = quantity + ? WHERE id = ?', [quantity || 1, existing.id]);
  } else {
    await db.run('INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?,?,?)', [cart.id, product_id, quantity || 1]);
  }
  sendJson(res, 200, await cartContents(cart.id));
});

route('PATCH', '/api/cart/items/:productId', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const { quantity } = await readJsonBody(req);
  const cart = await getOrCreateCart(session.uid);
  if (quantity <= 0) await db.run('DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?', [cart.id, params.productId]);
  else await db.run('UPDATE cart_items SET quantity = ? WHERE cart_id = ? AND product_id = ?', [quantity, cart.id, params.productId]);
  sendJson(res, 200, await cartContents(cart.id));
});

route('DELETE', '/api/cart/items/:productId', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const cart = await getOrCreateCart(session.uid);
  await db.run('DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?', [cart.id, params.productId]);
  sendJson(res, 200, await cartContents(cart.id));
});

// ---- Wishlist ----
route('GET', '/api/wishlist', async (req, res) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  sendJson(res, 200, await db.all(`SELECT p.* FROM wishlists w JOIN products p ON p.id = w.product_id WHERE w.user_id = ?`, [session.uid]));
});
route('POST', '/api/wishlist', async (req, res) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const { product_id } = await readJsonBody(req);
  try { await db.run('INSERT INTO wishlists (user_id, product_id) VALUES (?,?)', [session.uid, product_id]); } catch (e) {}
  sendJson(res, 200, { ok: true });
});
route('DELETE', '/api/wishlist/:productId', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  await db.run('DELETE FROM wishlists WHERE user_id = ? AND product_id = ?', [session.uid, params.productId]);
  sendJson(res, 200, { ok: true });
});

// ---- Orders / Checkout ----
route('POST', '/api/orders', async (req, res) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const body = await readJsonBody(req);
  const { recipient_name, phone, county, town, street, payment_provider } = body;
  if (!recipient_name || !isValidKenyanPhone(phone) || !county || !town || !street) {
    return sendJson(res, 400, { error: 'Complete delivery details with a valid Kenyan phone number are required' });
  }
  if (!['mpesa', 'card', 'paypal'].includes(payment_provider)) return sendJson(res, 400, { error: 'Select a payment method' });

  const cart = await getOrCreateCart(session.uid);
  const { items } = await cartContents(cart.id);
  if (items.length === 0) return sendJson(res, 400, { error: 'Your cart is empty' });

  const byStore = new Map();
  for (const item of items) {
    const p = await db.get('SELECT store_id FROM products WHERE id = ?', [item.product_id]);
    if (!byStore.has(p.store_id)) byStore.set(p.store_id, []);
    byStore.get(p.store_id).push(item);
  }

  const createdOrders = [];
  for (const [storeId, storeItems] of byStore) {
    for (const item of storeItems) {
      const inv = await db.get('SELECT quantity FROM inventory WHERE product_id = ?', [item.product_id]);
      if (!inv || inv.quantity < item.quantity) {
        return sendJson(res, 409, { error: `Not enough stock for ${item.name}` });
      }
    }
    const subtotal = storeItems.reduce((s, i) => s + (i.sale_price_kes || i.price_kes) * i.quantity, 0);
    const deliveryFee = 300;
    const total = subtotal + deliveryFee;
    const num = orderNumber();
    const info = await db.run(`INSERT INTO orders (order_number, customer_id, store_id, subtotal_kes, delivery_fee_kes, total_kes, recipient_name, phone, county, town, street)
      VALUES (?,?,?,?,?,?,?,?,?,?,?)`, [num, session.uid, storeId, subtotal, deliveryFee, total, recipient_name, normalizeKenyanPhone(phone), county, town, street]);
    const orderId = info.lastInsertRowid;
    for (const item of storeItems) {
      await db.run('INSERT INTO order_items (order_id, product_id, product_name, unit_price_kes, quantity) VALUES (?,?,?,?,?)',
        [orderId, item.product_id, item.name, item.sale_price_kes || item.price_kes, item.quantity]);
      await db.run(`UPDATE inventory SET quantity = quantity - ?, updated_at = CURRENT_TIMESTAMP WHERE product_id = ?`, [item.quantity, item.product_id]);
    }
    await db.run("INSERT INTO payments (order_id, provider, amount_kes, status) VALUES (?,?,?,'initiated')", [orderId, payment_provider, total]);
    createdOrders.push({ id: orderId, order_number: num, total_kes: total });
  }
  await db.run('DELETE FROM cart_items WHERE cart_id = ?', [cart.id]);
  // NOTE: orders remain in 'pending' status until a real payment provider webhook
  // confirms payment (see /api/webhooks/*). This intentionally does not fake success.
  sendJson(res, 201, { orders: createdOrders });
});

route('GET', '/api/orders', async (req, res) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const orders = await db.all(`SELECT o.*, s.name AS store_name FROM orders o JOIN stores s ON s.id = o.store_id WHERE customer_id = ? ORDER BY o.created_at DESC`, [session.uid]);
  sendJson(res, 200, orders);
});

route('GET', '/api/orders/:id', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['customer', 'seller', 'admin']); if (!session) return;
  const order = await db.get('SELECT * FROM orders WHERE id = ?', [params.id]);
  if (!order) return sendJson(res, 404, { error: 'Order not found' });
  if (session.role === 'customer' && order.customer_id !== session.uid) return sendJson(res, 403, { error: 'Not authorized' });
  if (session.role === 'seller') {
    const store = await db.get('SELECT id FROM stores WHERE seller_id = ?', [session.uid]);
    if (!store || store.id !== order.store_id) return sendJson(res, 403, { error: 'Not authorized' });
  }
  order.items = await db.all('SELECT * FROM order_items WHERE order_id = ?', [params.id]);
  order.payment = await db.get('SELECT provider, status, amount_kes FROM payments WHERE order_id = ?', [params.id]);
  sendJson(res, 200, order);
});

// ---- Payments: M-Pesa (STK Push) ----
// Confirms an order belongs to the requesting customer and has a payment
// record still awaiting confirmation, before letting them (re)trigger it.
async function loadPayableOrder(res, session, orderId) {
  const order = await db.get('SELECT * FROM orders WHERE id = ?', [orderId]);
  if (!order) { sendJson(res, 404, { error: 'Order not found' }); return null; }
  if (order.customer_id !== session.uid) { sendJson(res, 403, { error: 'Not authorized' }); return null; }
  if (order.status !== 'pending') { sendJson(res, 409, { error: 'This order has already been paid or is no longer payable' }); return null; }
  return order;
}

route('POST', '/api/payments/mpesa/stk-push', async (req, res) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  if (!mpesa.isConfigured()) return sendJson(res, 501, { error: 'M-Pesa is not configured yet. See README.md → Payment setup.' });
  const { order_id, phone } = await readJsonBody(req);
  if (!isValidKenyanPhone(phone)) return sendJson(res, 400, { error: 'Enter a valid Kenyan M-Pesa phone number' });
  const order = await loadPayableOrder(res, session, order_id); if (!order) return;
  const payment = await db.get(`SELECT * FROM payments WHERE order_id = ? AND provider = 'mpesa'`, [order.id]);
  if (!payment) return sendJson(res, 400, { error: 'This order was not set up for M-Pesa payment' });

  try {
    const normalizedPhone = normalizeKenyanPhone(phone).replace('+', '');
    const result = await mpesa.stkPush({ phone: normalizedPhone, amount: order.total_kes, orderId: order.id, orderNumber: order.order_number });
    await db.run(
      `UPDATE payments SET status = 'pending', checkout_request_id = ?, provider_reference = ?, phone = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
      [result.CheckoutRequestID, result.MerchantRequestID, normalizedPhone, payment.id]
    );
    sendJson(res, 200, { success: true, checkoutRequestId: result.CheckoutRequestID, message: result.CustomerMessage || 'Check your phone and enter your M-Pesa PIN to complete payment.' });
  } catch (err) {
    console.error('[mpesa] STK push failed:', err.message);
    sendJson(res, 502, { error: 'Could not reach M-Pesa. Please try again in a moment.' });
  }
});

// Safaricom POSTs the STK push result here — this is a public, unauthenticated
// endpoint by necessity (Safaricom's servers call it directly), so it never
// trusts anything beyond the CheckoutRequestID it already issued us.
route('POST', '/api/webhooks/mpesa/callback', async (req, res) => {
  const body = await readJsonBody(req);
  const parsed = MpesaService.parseCallback(body);
  if (!parsed) { res.writeHead(200); return res.end('OK'); } // ack anyway — malformed body isn't Safaricom's problem to retry forever

  const payment = await db.get('SELECT * FROM payments WHERE checkout_request_id = ?', [parsed.checkoutRequestId]);
  if (!payment) { res.writeHead(200); return res.end('OK'); }

  if (parsed.success) {
    await db.run(
      `UPDATE payments SET status = 'successful', transaction_id = ?, result_desc = ?, provider_response = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
      [parsed.mpesaReceiptNumber, parsed.resultDesc, JSON.stringify(body), payment.id]
    );
    await db.run(`UPDATE orders SET status = 'paid', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [payment.order_id]);
  } else {
    await db.run(
      `UPDATE payments SET status = 'failed', result_desc = ?, provider_response = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
      [mpesaResultMessage(parsed.resultCode), JSON.stringify(body), payment.id]
    );
  }
  res.writeHead(200); res.end('OK');
});

route('GET', '/api/payments/mpesa/status/:checkoutRequestId', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const payment = await db.get('SELECT p.*, o.customer_id, o.id AS order_id, o.order_number FROM payments p JOIN orders o ON o.id = p.order_id WHERE p.checkout_request_id = ?', [params.checkoutRequestId]);
  if (!payment || payment.customer_id !== session.uid) return sendJson(res, 404, { error: 'Payment not found' });
  sendJson(res, 200, {
    status: payment.status,
    completed: payment.status === 'successful',
    failed: payment.status === 'failed',
    message: payment.result_desc,
    orderId: payment.order_id,
    orderNumber: payment.order_number,
  });
});

// ---- Payments: PayPal ----
route('POST', '/api/payments/paypal/create-order', async (req, res) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  if (!paypal.isConfigured()) return sendJson(res, 501, { error: 'PayPal is not configured yet. See README.md → Payment setup.' });
  const { order_id } = await readJsonBody(req);
  const order = await loadPayableOrder(res, session, order_id); if (!order) return;
  const items = await db.all('SELECT * FROM order_items WHERE order_id = ?', [order.id]);

  try {
    // PayPal doesn't settle in KES, so the checkout page must display and
    // charge in USD for this path — see README → Payment setup for the
    // conversion-rate note; this uses a fixed rate pulled from env for now.
    const rate = Number(process.env.KES_TO_USD_RATE || 0.0077);
    const usdTotal = Math.round(order.total_kes * rate * 100) / 100;
    const paypalOrder = await paypal.createOrder({
      orderId: order.id,
      amount: usdTotal,
      currency: 'USD',
      items: items.map(item => ({ name: item.product_name, quantity: item.quantity, price: Math.round(item.unit_price_kes * rate * 100) / 100 })),
    });
    await db.run(
      `INSERT INTO payments (order_id, provider, provider_reference, amount_kes, currency, status) VALUES (?,?,?,?,?,'pending')`,
      [order.id, 'paypal', paypalOrder.id, order.total_kes, 'USD']
    );
    const approvalUrl = paypalOrder.links.find(l => l.rel === 'approve')?.href;
    sendJson(res, 200, { orderId: paypalOrder.id, approvalUrl });
  } catch (err) {
    console.error('[paypal] Order creation failed:', err.message);
    sendJson(res, 502, { error: 'Could not start PayPal checkout. Please try again.' });
  }
});

route('POST', '/api/payments/paypal/capture/:paypalOrderId', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const payment = await db.get('SELECT p.*, o.customer_id FROM payments p JOIN orders o ON o.id = p.order_id WHERE p.provider_reference = ? AND p.provider = \'paypal\'', [params.paypalOrderId]);
  if (!payment || payment.customer_id !== session.uid) return sendJson(res, 404, { error: 'Payment not found' });

  try {
    const capture = await paypal.captureOrder(params.paypalOrderId);
    if (capture.status === 'COMPLETED') {
      const captureId = capture.purchase_units?.[0]?.payments?.captures?.[0]?.id;
      await db.run(
        `UPDATE payments SET status = 'successful', transaction_id = ?, provider_response = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [captureId, JSON.stringify(capture), payment.id]
      );
      await db.run(`UPDATE orders SET status = 'paid', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [payment.order_id]);
      sendJson(res, 200, { success: true, orderId: payment.order_id });
    } else {
      sendJson(res, 400, { error: 'Payment was not completed' });
    }
  } catch (err) {
    console.error('[paypal] Capture failed:', err.message);
    sendJson(res, 502, { error: 'Could not confirm PayPal payment. Please try again.' });
  }
});

route('GET', '/api/payments/paypal/status/:paypalOrderId', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['customer']); if (!session) return;
  const payment = await db.get('SELECT p.*, o.customer_id, o.id AS order_id FROM payments p JOIN orders o ON o.id = p.order_id WHERE p.provider_reference = ? AND p.provider = \'paypal\'', [params.paypalOrderId]);
  if (!payment || payment.customer_id !== session.uid) return sendJson(res, 404, { error: 'Payment not found' });
  sendJson(res, 200, { status: payment.status, completed: payment.status === 'successful', orderId: payment.order_id });
});

// PayPal webhook — verifies the signature against PayPal before trusting
// the event, per PayPal's documented verification flow.
route('POST', '/api/webhooks/paypal', async (req, res) => {
  if (!paypal.isConfigured()) return sendJson(res, 501, { error: 'PayPal is not configured yet.' });
  const body = await readJsonBody(req);
  const verified = await paypal.verifyWebhook(body, req.headers);
  if (!verified) return sendJson(res, 401, { error: 'Invalid webhook signature' });

  const event = body;
  try {
    if (event.event_type === 'PAYMENT.CAPTURE.COMPLETED') {
      const paypalOrderId = event.resource?.supplementary_data?.related_ids?.order_id;
      if (paypalOrderId) {
        const payment = await db.get(`SELECT * FROM payments WHERE provider_reference = ? AND provider = 'paypal'`, [paypalOrderId]);
        if (payment && payment.status !== 'successful') {
          await db.run(`UPDATE payments SET status = 'successful', transaction_id = ?, provider_response = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [event.resource.id, JSON.stringify(event), payment.id]);
          await db.run(`UPDATE orders SET status = 'paid', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [payment.order_id]);
        }
      }
    } else if (event.event_type === 'PAYMENT.CAPTURE.DENIED') {
      const captureId = event.resource?.id;
      await db.run(`UPDATE payments SET status = 'failed', provider_response = ?, updated_at = CURRENT_TIMESTAMP WHERE transaction_id = ?`, [JSON.stringify(event), captureId]);
    } else if (event.event_type === 'PAYMENT.CAPTURE.REFUNDED') {
      const captureId = event.resource?.id;
      await db.run(`UPDATE payments SET status = 'refunded', provider_response = ?, updated_at = CURRENT_TIMESTAMP WHERE transaction_id = ?`, [JSON.stringify(event), captureId]);
    }
    res.writeHead(200); res.end('OK');
  } catch (err) {
    console.error('[paypal webhook]', err);
    res.writeHead(500); res.end();
  }
});

// Public, non-secret config the frontend needs to decide what to render
// (e.g. whether to load the PayPal SDK at all). Never put secrets here.
route('GET', '/api/config', async (req, res) => {
  sendJson(res, 200, {
    paypal_enabled: paypal.isConfigured(),
    paypal_client_id: paypal.isConfigured() ? process.env.PAYPAL_CLIENT_ID : null,
    mpesa_enabled: mpesa.isConfigured(),
    uploads_persistent: storage.isConfigured() || !isProd,
  });
});

// ---- Seller ----
async function sellerStoreOrRespond(res, sellerId) {
  const store = await db.get('SELECT * FROM stores WHERE seller_id = ?', [sellerId]);
  if (!store) sendJson(res, 404, { error: 'Create your store first' });
  return store;
}

route('POST', '/api/seller/store', async (req, res) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const existing = await db.get('SELECT id FROM stores WHERE seller_id = ?', [session.uid]);
  if (existing) return sendJson(res, 409, { error: 'You already have a store' });
  const { name, description, county, town } = await readJsonBody(req);
  if (!name || !name.trim()) return sendJson(res, 400, { error: 'Store name is required' });
  let slug = slugify(name);
  if (await db.get('SELECT id FROM stores WHERE slug = ?', [slug])) slug += '-' + Math.floor(Math.random() * 1000);
  const info = await db.run('INSERT INTO stores (seller_id, name, slug, description, county, town) VALUES (?,?,?,?,?,?)',
    [session.uid, name.trim(), slug, description || '', county || '', town || '']);
  sendJson(res, 201, { id: info.lastInsertRowid, slug });
});

route('GET', '/api/seller/store', async (req, res) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const store = await db.get('SELECT * FROM stores WHERE seller_id = ?', [session.uid]);
  sendJson(res, 200, store || null);
});

route('PATCH', '/api/seller/store', async (req, res) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const store = await sellerStoreOrRespond(res, session.uid); if (!store) return;
  const { name, description, county, town } = await readJsonBody(req);
  await db.run('UPDATE stores SET name = ?, description = ?, county = ?, town = ? WHERE id = ?',
    [name || store.name, description ?? store.description, county ?? store.county, town ?? store.town, store.id]);
  sendJson(res, 200, { ok: true });
});

route('GET', '/api/seller/products', async (req, res) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const store = await sellerStoreOrRespond(res, session.uid); if (!store) return;
  const products = await db.all(`SELECT p.*, COALESCE(i.quantity,0) AS stock,
    (SELECT url FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) AS image
    FROM products p LEFT JOIN inventory i ON i.product_id = p.id WHERE store_id = ? ORDER BY p.created_at DESC`, [store.id]);
  sendJson(res, 200, products);
});

route('POST', '/api/seller/products', async (req, res) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const store = await sellerStoreOrRespond(res, session.uid); if (!store) return;
  const { name, description, price_kes, sale_price_kes, category_id, sku, stock, image_url } = await readJsonBody(req);
  if (!name || !name.trim()) return sendJson(res, 400, { error: 'Product name is required' });
  if (!price_kes || price_kes <= 0) return sendJson(res, 400, { error: 'A valid price in KES is required' });
  let slug = slugify(name);
  if (await db.get('SELECT id FROM products WHERE store_id = ? AND slug = ?', [store.id, slug])) slug += '-' + Math.floor(Math.random() * 1000);
  const info = await db.run(`INSERT INTO products (store_id, category_id, name, slug, description, price_kes, sale_price_kes, sku) VALUES (?,?,?,?,?,?,?,?)`,
    [store.id, category_id || null, name.trim(), slug, description || '', price_kes, sale_price_kes || null, sku || null]);
  const productId = info.lastInsertRowid;
  await db.run('INSERT INTO inventory (product_id, quantity) VALUES (?,?)', [productId, stock || 0]);
  if (image_url) await db.run('INSERT INTO product_images (product_id, url, sort_order) VALUES (?,?,0)', [productId, image_url]);
  sendJson(res, 201, { id: productId, slug });
});

route('PATCH', '/api/seller/products/:id', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const store = await sellerStoreOrRespond(res, session.uid); if (!store) return;
  const product = await db.get('SELECT * FROM products WHERE id = ? AND store_id = ?', [params.id, store.id]);
  if (!product) return sendJson(res, 404, { error: 'Product not found' });
  const body = await readJsonBody(req);
  const fields = ['name', 'description', 'price_kes', 'sale_price_kes', 'category_id', 'sku', 'is_active', 'is_featured'];
  const updates = fields.filter(f => body[f] !== undefined);
  if (updates.length) {
    await db.run(`UPDATE products SET ${updates.map(f => `${f} = ?`).join(', ')} WHERE id = ?`, [...updates.map(f => body[f]), params.id]);
  }
  if (body.stock !== undefined) {
    await db.run(`UPDATE inventory SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE product_id = ?`, [body.stock, params.id]);
  }
  if (body.image_url) {
    await db.run('DELETE FROM product_images WHERE product_id = ?', [params.id]);
    await db.run('INSERT INTO product_images (product_id, url, sort_order) VALUES (?,?,0)', [params.id, body.image_url]);
  }
  sendJson(res, 200, { ok: true });
});

route('DELETE', '/api/seller/products/:id', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const store = await sellerStoreOrRespond(res, session.uid); if (!store) return;
  const result = await db.run('DELETE FROM products WHERE id = ? AND store_id = ?', [params.id, store.id]);
  if (!result.changes) return sendJson(res, 404, { error: 'Product not found' });
  sendJson(res, 200, { ok: true });
});

// Real image upload — accepts a base64 data URL (from FileReader on the
// client), validates type/size, and stores it. Uses Supabase Storage when
// SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY are set (survives deploys/
// restarts — required on Render's ephemeral disk); otherwise falls back to
// local disk under /public/uploads for local development only. Which path
// ran is visible in the response so this never fails silently.
route('POST', '/api/seller/uploads', async (req, res) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const { image_base64 } = await readJsonBody(req, 7_000_000);
  const parsed = parseImageDataUrl(image_base64);
  if (parsed.error) return sendJson(res, 400, { error: parsed.error });

  if (storage.isConfigured()) {
    try {
      const mime = /^data:([^;]+);/.exec(image_base64)[1];
      const url = await storage.upload(parsed.buffer, mime, parsed.ext);
      return sendJson(res, 201, { url, storage: 'supabase' });
    } catch (err) {
      console.error('[uploads] Supabase Storage upload failed:', err.message);
      return sendJson(res, 502, { error: 'Image upload failed. Please try again.' });
    }
  }

  if (isProd) {
    // Don't silently write to local disk in production and let images
    // vanish on the next deploy — fail loudly and say exactly why.
    return sendJson(res, 501, {
      error: 'Image storage is not configured. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (see README.md → Object storage setup) — local disk does not persist on this host.',
    });
  }
  const filename = `${crypto.randomBytes(12).toString('hex')}.${parsed.ext}`;
  await fs.promises.writeFile(path.join(UPLOADS_DIR, filename), parsed.buffer);
  sendJson(res, 201, { url: `/uploads/${filename}`, storage: 'local-dev' });
});

route('GET', '/api/seller/orders', async (req, res) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const store = await sellerStoreOrRespond(res, session.uid); if (!store) return;
  const orders = await db.all(`SELECT o.*, u.full_name AS customer_name FROM orders o JOIN users u ON u.id = o.customer_id WHERE store_id = ? ORDER BY o.created_at DESC`, [store.id]);
  sendJson(res, 200, orders);
});

route('PATCH', '/api/seller/orders/:id/status', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const store = await sellerStoreOrRespond(res, session.uid); if (!store) return;
  const { status } = await readJsonBody(req);
  const valid = ['pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'];
  if (!valid.includes(status)) return sendJson(res, 400, { error: 'Invalid status' });
  const result = await db.run(`UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND store_id = ?`, [status, params.id, store.id]);
  if (!result.changes) return sendJson(res, 404, { error: 'Order not found' });
  sendJson(res, 200, { ok: true });
});

route('GET', '/api/seller/stats', async (req, res) => {
  const session = requireAuth(req, res, ['seller']); if (!session) return;
  const store = await sellerStoreOrRespond(res, session.uid); if (!store) return;
  const revenue = (await db.get(`SELECT COALESCE(SUM(total_kes),0) AS total FROM orders WHERE store_id = ? AND status != 'cancelled'`, [store.id])).total;
  const orderCount = (await db.get('SELECT COUNT(*) AS c FROM orders WHERE store_id = ?', [store.id])).c;
  const productCount = (await db.get('SELECT COUNT(*) AS c FROM products WHERE store_id = ?', [store.id])).c;
  const lowStock = await db.all(`SELECT p.name, i.quantity FROM inventory i JOIN products p ON p.id = i.product_id WHERE p.store_id = ? AND i.quantity <= i.low_stock_threshold`, [store.id]);
  sendJson(res, 200, { revenue_kes: revenue, order_count: orderCount, product_count: productCount, low_stock: lowStock });
});

// ---- Admin ----
route('GET', '/api/admin/stats', async (req, res) => {
  const session = requireAuth(req, res, ['admin']); if (!session) return;
  const users = (await db.get('SELECT COUNT(*) AS c FROM users')).c;
  const sellers = (await db.get(`SELECT COUNT(*) AS c FROM users WHERE role = 'seller'`)).c;
  const stores = (await db.get('SELECT COUNT(*) AS c FROM stores')).c;
  const orders = (await db.get('SELECT COUNT(*) AS c FROM orders')).c;
  const revenue = (await db.get(`SELECT COALESCE(SUM(total_kes),0) AS t FROM orders WHERE status != 'cancelled'`)).t;
  sendJson(res, 200, { users, sellers, stores, orders, revenue_kes: revenue });
});

route('GET', '/api/admin/users', async (req, res) => {
  const session = requireAuth(req, res, ['admin']); if (!session) return;
  sendJson(res, 200, await db.all('SELECT id, email, full_name, role, status, created_at FROM users ORDER BY created_at DESC'));
});

route('PATCH', '/api/admin/users/:id/status', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['admin']); if (!session) return;
  const { status } = await readJsonBody(req);
  if (!['active', 'suspended'].includes(status)) return sendJson(res, 400, { error: 'Invalid status' });
  await db.run('UPDATE users SET status = ? WHERE id = ?', [status, params.id]);
  sendJson(res, 200, { ok: true });
});

route('GET', '/api/admin/stores', async (req, res) => {
  const session = requireAuth(req, res, ['admin']); if (!session) return;
  sendJson(res, 200, await db.all(`SELECT s.*, u.full_name AS seller_name, u.email AS seller_email FROM stores s JOIN users u ON u.id = s.seller_id ORDER BY s.created_at DESC`));
});

route('PATCH', '/api/admin/stores/:id/status', async (req, res, query, params) => {
  const session = requireAuth(req, res, ['admin']); if (!session) return;
  const { status } = await readJsonBody(req);
  if (!['active', 'suspended'].includes(status)) return sendJson(res, 400, { error: 'Invalid status' });
  await db.run('UPDATE stores SET status = ? WHERE id = ?', [status, params.id]);
  sendJson(res, 200, { ok: true });
});

route('GET', '/api/admin/orders', async (req, res) => {
  const session = requireAuth(req, res, ['admin']); if (!session) return;
  sendJson(res, 200, await db.all(`SELECT o.*, s.name AS store_name, u.full_name AS customer_name FROM orders o JOIN stores s ON s.id=o.store_id JOIN users u ON u.id=o.customer_id ORDER BY o.created_at DESC LIMIT 200`));
});

// ---- Paystack webhook (card payments — structure only, see README) ----
route('POST', '/api/webhooks/paystack', async (req, res) => {
  if (!process.env.PAYSTACK_SECRET_KEY) {
    return sendJson(res, 501, { error: 'Paystack credentials not configured. See README.md → Payment setup.' });
  }
  const body = await readJsonBody(req);
  // TODO: verify x-paystack-signature header using PAYSTACK_SECRET_KEY (HMAC-SHA512
  // of the raw body), then update payments/orders on a match.
  sendJson(res, 200, { received: true });
});

// ---- SEO: robots.txt + dynamic sitemap.xml ----
route('GET', '/robots.txt', async (req, res) => {
  const origin = process.env.PUBLIC_URL || `http://${req.headers.host}`;
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end(`User-agent: *\nAllow: /\nDisallow: /account\nDisallow: /cart\nDisallow: /checkout\nDisallow: /orders\nDisallow: /seller/\nDisallow: /admin/\n\nSitemap: ${origin}/sitemap.xml\n`);
});
route('GET', '/sitemap.xml', async (req, res) => {
  const origin = process.env.PUBLIC_URL || `http://${req.headers.host}`;
  const products = await db.all(`SELECT p.id, p.created_at FROM products p JOIN stores s ON s.id=p.store_id WHERE p.is_active=1 AND s.status='active' AND s.is_published=1`);
  const staticUrls = ['/', '/product'];
  const urls = [
    ...staticUrls.map(u => `<url><loc>${origin}${u}</loc><changefreq>daily</changefreq></url>`),
    ...products.map(p => `<url><loc>${origin}/product?id=${p.id}</loc><lastmod>${new Date(p.created_at).toISOString().slice(0,10)}</lastmod><changefreq>weekly</changefreq></url>`),
  ];
  res.writeHead(200, { 'Content-Type': 'application/xml' });
  res.end(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join('\n')}\n</urlset>`);
});

// ============================================================
// Server
// ============================================================
const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = decodeURIComponent(parsed.pathname);

  // Baseline security headers on every response.
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  if (pathname.startsWith('/api/')) {
    // CORS: explicit origin in production (reflects only the configured
    // origin, never '*', so credentials-bearing requests stay safe);
    // permissive '*' locally for convenience since there's nothing to steal.
    if (process.env.CORS_ORIGIN) {
      res.setHeader('Access-Control-Allow-Origin', process.env.CORS_ORIGIN);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
    } else if (!isProd) {
      res.setHeader('Access-Control-Allow-Origin', '*');
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

    const isAuthRoute = pathname.startsWith('/api/auth/');
    if (isAuthRoute && isAuthRateLimited(req)) return sendJson(res, 429, { error: 'Too many attempts, please wait a minute and try again' });
    if (!isAuthRoute && isRateLimited(req, 60, 60_000)) return sendJson(res, 429, { error: 'Too many requests, please slow down' });

    const match = routes.find(r => r.method === req.method && r.regex.test(pathname));
    if (!match) return sendJson(res, 404, { error: 'No such API route' });
    const values = match.regex.exec(pathname).slice(1);
    const params = Object.fromEntries(match.keys.map((k, i) => [k, values[i]]));
    try {
      await match.handler(req, res, parsed.query, params);
    } catch (err) {
      console.error(err);
      sendJson(res, 500, { error: 'Something went wrong on our end' });
    }
    return;
  }

  if (pathname === '/robots.txt' || pathname === '/sitemap.xml') {
    const match = routes.find(r => r.method === 'GET' && r.regex.test(pathname));
    if (match) { try { await match.handler(req, res, parsed.query, {}); } catch (e) { res.writeHead(500); res.end(); } return; }
  }

  serveStatic(req, res, pathname);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Afrishop server running on port ${PORT} (db engine: ${db.engine})`);
});
