// seed.js — populates demo data for local testing and evaluation.
// Run with: node seed.js  (or: npm run seed)
const db = require('./db');
const { hashPassword } = require('./lib/auth');

async function upsertUser(email, password, full_name, role, phone) {
  let user = await db.get('SELECT * FROM users WHERE email = ?', [email]);
  if (user) return user;
  const { hash, salt } = hashPassword(password);
  const info = await db.run('INSERT INTO users (email, password_hash, password_salt, full_name, role, phone) VALUES (?,?,?,?,?,?)',
    [email, hash, salt, full_name, role, phone || null]);
  return { id: info.lastInsertRowid, email, full_name, role };
}

async function main() {
  console.log('Seeding Afrishop demo data...');

  const admin = await upsertUser('admin@afrishop.co.ke', 'AdminPass123', 'Platform Admin', 'admin');
  const seller = await upsertUser('amaka@afrishop.co.ke', 'SellerPass123', 'Amaka Nwosu', 'seller', '+254712345678');
  const customer = await upsertUser('jane@afrishop.co.ke', 'CustomerPass123', 'Jane Wanjiru', 'customer', '+254798765432');

  let store = await db.get('SELECT * FROM stores WHERE seller_id = ?', [seller.id]);
  if (!store) {
    const info = await db.run(`INSERT INTO stores (seller_id, name, slug, description, county, town) VALUES (?,?,?,?,?,?)`,
      [seller.id, 'Amaka Textiles', 'amaka-textiles', 'Handwoven, indigo-dyed textiles and accessories.', 'Nairobi', 'Westlands']);
    store = { id: info.lastInsertRowid };
  }

  const categories = ['Apparel', 'Bags', 'Accessories', 'Footwear'];
  const catIds = {};
  for (const name of categories) {
    let cat = await db.get('SELECT * FROM categories WHERE slug = ?', [name.toLowerCase()]);
    if (!cat) {
      const info = await db.run('INSERT INTO categories (name, slug) VALUES (?,?)', [name, name.toLowerCase()]);
      cat = { id: info.lastInsertRowid };
    }
    catIds[name] = cat.id;
  }

  const products = [
    { name: 'Adire Wrap', category: 'Apparel', price: 4200, sale: null, stock: 22 },
    { name: 'Indigo Tote', category: 'Bags', price: 2600, sale: null, stock: 40 },
    { name: 'Kola Scarf', category: 'Accessories', price: 1800, sale: 1500, stock: 4 },
    { name: 'Woven Sandals', category: 'Footwear', price: 3400, sale: null, stock: 15 },
    { name: 'Beaded Clutch', category: 'Accessories', price: 2900, sale: null, stock: 18 },
    { name: 'Coastal Kaftan', category: 'Apparel', price: 5600, sale: 4800, stock: 9 },
  ];

  for (const p of products) {
    const slug = p.name.toLowerCase().replace(/\s+/g, '-');
    const existing = await db.get('SELECT id FROM products WHERE store_id = ? AND slug = ?', [store.id, slug]);
    if (existing) continue;
    const info = await db.run(`INSERT INTO products (store_id, category_id, name, slug, description, price_kes, sale_price_kes, is_featured) VALUES (?,?,?,?,?,?,?,?)`,
      [store.id, catIds[p.category], p.name, slug, `${p.name} — handcrafted by Amaka Textiles.`, p.price, p.sale, p.sale ? 1 : 0]);
    const productId = info.lastInsertRowid;
    await db.run('INSERT INTO inventory (product_id, quantity, low_stock_threshold) VALUES (?,?,5)', [productId, p.stock]);
  }

  console.log('Seed complete.');
  console.log('');
  console.log('Demo accounts:');
  console.log('  Admin:    admin@afrishop.co.ke / AdminPass123');
  console.log('  Seller:   amaka@afrishop.co.ke / SellerPass123  (store: Amaka Textiles)');
  console.log('  Customer: jane@afrishop.co.ke / CustomerPass123');
  process.exit(0);
}

main().catch(err => { console.error('Seed failed:', err); process.exit(1); });
