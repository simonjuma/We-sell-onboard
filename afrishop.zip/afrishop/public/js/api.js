// api.js — shared fetch wrapper + small UI helpers used across every page.
const API = {
  async req(method, path, body) {
    const res = await fetch('/api' + path, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      credentials: 'include',
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Something went wrong');
    return data;
  },
  get(path) { return this.req('GET', path); },
  post(path, body) { return this.req('POST', path, body); },
  patch(path, body) { return this.req('PATCH', path, body); },
  del(path) { return this.req('DELETE', path); },
};

function toast(msg) {
  let el = document.querySelector('.toast');
  if (!el) { el = document.createElement('div'); el.className = 'toast'; document.body.appendChild(el); }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 2600);
}

function fmtKES(n) { return 'KES ' + Number(n).toLocaleString(); }

async function refreshCartCount() {
  const el = document.getElementById('cartCount');
  if (!el) return;
  try {
    const me = await API.get('/auth/me');
    if (!me.user || me.user.role !== 'customer') { el.style.display = 'none'; return; }
    const cart = await API.get('/cart');
    const count = cart.items.reduce((s, i) => s + i.quantity, 0);
    el.textContent = count;
    el.style.display = count > 0 ? 'flex' : 'none';
  } catch (e) { /* not logged in — fine */ }
}

async function renderAuthNav() {
  const el = document.getElementById('authNavSlot');
  if (!el) return;
  try {
    const { user } = await API.get('/auth/me');
    if (user) {
      el.innerHTML = `<a href="/account" class="icon-btn" title="${user.full_name}">👤</a>` +
        (user.role === 'seller' ? `<a href="/seller/dashboard" class="btn btn-outline btn-sm">Seller dashboard</a>` : '') +
        (user.role === 'admin' ? `<a href="/admin/dashboard" class="btn btn-outline btn-sm">Admin</a>` : '');
    } else {
      el.innerHTML = `<a href="/account" class="btn btn-outline btn-sm">Log in</a>`;
    }
  } catch (e) {}
}
